package main.dataclicker.buyers;

public class Buyers_Template {
    private String name;
    private int level;
    private int preis;
    private int gewinn;

    public Buyers_Template() {
    }

    public void kauf() {
        throw new Error("Unresolved compilation problems: \n\tdataAmount cannot be resolved to a variable\n\tdataAmount cannot be resolved to a variable\n\tdataAmount cannot be resolved to a variable\n\tamountOfMoney cannot be resolved to a variable\n\tamountOfMoney cannot be resolved to a variable\n");
    }
}