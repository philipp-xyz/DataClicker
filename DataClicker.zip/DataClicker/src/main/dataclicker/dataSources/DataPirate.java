package main.dataclicker.dataSources;

public class DataPirate {
}
