package main.dataclicker.dataSources;

public class DataFarm {
}
