package main.dataclicker.dataSources;

public class DataScout24 {
}
