package main.dataclicker.dataSources;

public class DataHub {
}
