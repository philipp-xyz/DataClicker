package main.dataclicker.upgrades;

public class Upgrades_Template {
    public Upgrades_Template() {
    }
}